Be cordial or be on your way. --Kenneth Reitz

https://www.kennethreitz.org/essays/be-cordial-or-be-on-your-way
